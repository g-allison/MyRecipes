

# InlineObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredientList** | **String** | The ingredient list of the recipe, one ingredient per line. | 




