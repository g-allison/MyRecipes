

# InlineObject6

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | The title of the recipe. | 
**ingredientList** | **String** | The ingredient list of the recipe, one ingredient per line (separate lines with \\n). | 




